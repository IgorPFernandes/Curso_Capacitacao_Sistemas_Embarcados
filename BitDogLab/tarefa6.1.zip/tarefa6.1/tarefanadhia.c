#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "inc/ssd1306.h"
#include "hardware/i2c.h"

#define PINO_LED_VERMELHO 13
#define PINO_LED_VERDE 11
#define PINO_LED_AZUL 12
#define PINO_BOTAO_A 5

#define PORTA_I2C i2c0
const uint PINO_I2C_SDA = 14;
const uint PINO_I2C_SCL = 15;

int estado_botao_A = 0; // Estado do botão
ssd1306_t display_oled; // Instância do display OLED

void limparDisplay();
void inicializarOLED();
void exibirMensagem(const char *mensagem);
void mostrarSinalAberto();
void mostrarSinalFechado();
void mostrarSinalAmarelo();
int esperarComLeitura(int tempoMS);

int main() {
    gpio_init(PINO_LED_VERMELHO);
    gpio_set_dir(PINO_LED_VERMELHO, GPIO_OUT);
    gpio_init(PINO_LED_VERDE);
    gpio_set_dir(PINO_LED_VERDE, GPIO_OUT);
    gpio_init(PINO_LED_AZUL);
    gpio_set_dir(PINO_LED_AZUL, GPIO_OUT);

    gpio_init(PINO_BOTAO_A);
    gpio_set_dir(PINO_BOTAO_A, GPIO_IN);
    gpio_pull_up(PINO_BOTAO_A);

    inicializarOLED();

    while (true) {
        mostrarSinalFechado();
        estado_botao_A = esperarComLeitura(8000);

        if (estado_botao_A) {
            mostrarSinalAmarelo();
            sleep_ms(5000);
        } 

        mostrarSinalAberto();
        sleep_ms(13000);

        limparDisplay();
    }

    return 0;
}

void limparDisplay() {
    struct render_area area_renderizacao = {
        .start_column = 0,
        .end_column = ssd1306_width - 1,
        .start_page = 0,
        .end_page = ssd1306_n_pages - 1
    };

    calculate_render_area_buffer_length(&area_renderizacao);

    uint8_t buffer_display[ssd1306_buffer_length];
    memset(buffer_display, 0, ssd1306_buffer_length);
    render_on_display(buffer_display, &area_renderizacao);
}

void inicializarOLED() {
    stdio_init_all();
    i2c_init(i2c1, ssd1306_i2c_clock * 1000);
    gpio_set_function(PINO_I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(PINO_I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(PINO_I2C_SDA);
    gpio_pull_up(PINO_I2C_SCL);
    ssd1306_init();
}

void exibirMensagem(const char *mensagem) {
    struct render_area area_renderizacao = {
        .start_column = 0,
        .end_column = ssd1306_width - 1,
        .start_page = 0,
        .end_page = ssd1306_n_pages - 1
    };

    calculate_render_area_buffer_length(&area_renderizacao);

    uint8_t buffer_display[ssd1306_buffer_length];
    memset(buffer_display, 0, ssd1306_buffer_length);
    render_on_display(buffer_display, &area_renderizacao);

    int y = 0;
    const int altura_linha = 8;
    char mensagem_temp[256];
    strncpy(mensagem_temp, mensagem, sizeof(mensagem_temp));
    mensagem_temp[sizeof(mensagem_temp) - 1] = '\0';

    char *linha = strtok(mensagem_temp, "\n");
    while (linha != NULL) {
        ssd1306_draw_string(buffer_display, 5, y, linha);
        y += altura_linha;
        linha = strtok(NULL, "\n");
    }

    render_on_display(buffer_display, &area_renderizacao);
}

void mostrarSinalAberto() {
    gpio_put(PINO_LED_VERMELHO, 0);
    gpio_put(PINO_LED_VERDE, 1);
    gpio_put(PINO_LED_AZUL, 0);
    exibirMensagem("SINAL ABERTO\nATRAVESSAR\nCOM CUIDADO!");
}

void mostrarSinalFechado() {
    gpio_put(PINO_LED_VERMELHO, 1);
    gpio_put(PINO_LED_VERDE, 0);
    gpio_put(PINO_LED_AZUL, 0);
    exibirMensagem("SINAL FECHADO\nAGUARDE!");
}

void mostrarSinalAmarelo() {
    gpio_put(PINO_LED_VERMELHO, 1);
    gpio_put(PINO_LED_VERDE, 1);
    gpio_put(PINO_LED_AZUL, 0);
    exibirMensagem("SINAL AMARELO\nPREPARAR-SE!");
}

int esperarComLeitura(int tempoMS) {
    for (int i = 0; i < tempoMS; i += 100) {
        estado_botao_A = !gpio_get(PINO_BOTAO_A);
        if (estado_botao_A == 1) {
            return 1;
        }
        sleep_ms(100);
    }
    return 0;
}
