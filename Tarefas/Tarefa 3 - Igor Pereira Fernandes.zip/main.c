#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"
#include "hardware/pwm.h"
#include "hardware/clocks.h"

#define BUTTON_PIN 22
#define BUZ_PIN 21
#define R_PIN 20
#define Y_PIN 19
#define G_PIN 18
#define G_PIN_PED 17
#define BUZ_FREQ 2500 // O Transito é barulhento faz necessário uma frequência mais elevada

volatile bool button_pressed = false;

void semaforo();
void buttoninterrupt(uint gpio, uint32_t events);
void set_pwm_frequency(uint gpio, uint32_t frequency);

int main() {
  // Inicializando os pinos
  gpio_init(BUTTON_PIN);
  gpio_init(BUZ_PIN);
  gpio_init(R_PIN);
  gpio_init(Y_PIN);
  gpio_init(G_PIN);
  gpio_init(G_PIN_PED);
  // Configurando se os pinos são de entrada ou saída
  gpio_set_dir(BUTTON_PIN, GPIO_IN);
  gpio_set_dir(Y_PIN, GPIO_OUT);
  gpio_set_dir(R_PIN, GPIO_OUT);
  gpio_set_dir(G_PIN, GPIO_OUT);
  gpio_set_dir(G_PIN_PED, GPIO_OUT);
  gpio_set_dir(BUZ_PIN, GPIO_OUT);
  
  // Habilita pull-up interno no botão, evitando a necessidade de um resistor de pull-up no circuito.
  gpio_pull_down(BUTTON_PIN);

  // Configura a interrupção para detectar a borda de descida (quando o botão é pressionado)
  gpio_set_irq_enabled_with_callback(BUTTON_PIN, GPIO_IRQ_EDGE_FALL, true, &buttoninterrupt);

  /* Explicação do pull-up: Os microcontroladores possuem um sistema de proteção de portas para evitar
  que as entradas fiquem em alta impedância (flutuantes), o que pode causar comportamentos indesejados
  ou danificar o dispositivo. Para garantir que as entradas tenham um nível lógico bem definido, utilizamos
  resistores de pull-up (que conectam o pino ao VCC, mantendo o pino em nível alto quando não há sinal) ou
  pull-down (que conectam o pino ao GND, mantendo o pino em nível baixo). No entanto, ao programar diretamente
  os registradores do microcontrolador, muitos modelos permitem habilitar internamente os resistores de
  pull-up ou pull-down, dispensando a necessidade de resistores físicos no hardware e simplificando o circuito.*/

 while (true) {
    semaforo();
  }
}


/*Explicação: A interrupção é o metódo mais eficiente de executar esse projeto pela robustes
contra falhas no botão e ter uma melhor precisão quando o mesmo for acionado*/
//Função para a interrupção do botão, acionada quando o botão é pressionado
void buttoninterrupt(uint gpio, uint32_t events) {
    button_pressed = true;
}

/*Explicação da função: O slice trata-se de um CI chamado RP2040 que controla os PWM sem consumir processamento
do microcontrolador, cada slice possui sua propria frequencia determinada pelo divisor de clock
e o TOP, o slice é dividido em 2 canais A e B que podem ter frequencias de trabalho diferentes.
O divisor de clock ajusta a velocidade com que o contador do slice é incrementado, enquanto o 
TOP define o ponto em que o contador se reinicia, determinando assim a frequência do sinal PWM.*/

void set_pwm_frequency(uint gpio, uint32_t frequency) {
    gpio_set_function(gpio, GPIO_FUNC_PWM); // Configura o GPIO como saída PWM
    uint slice_num = pwm_gpio_to_slice_num(gpio); // Configura a frequência do PWM
    uint32_t clock_div = 4; // Divisor do clock (ajustável conforme necessário)
    uint16_t top = (clock_get_hz(clk_sys) / (clock_div * frequency)) - 1;
    pwm_set_clkdiv(slice_num, clock_div); // Configura o divisor de clock
    pwm_set_wrap(slice_num, top); // Configura o valor máximo do contador
    pwm_set_gpio_level(gpio, top/2); // Define o ciclo de trabalho como 50% (nível ideal para buzzers passivos)
    //Coloquei em 50% porquê não quero que o volume seja ensurdecedor, pos ele já está em uma frequência de alarme
    pwm_set_enabled(slice_num, true); // Ativa o slice de PWM
}

// Lógica do semáforo
void semaforo() {
    static uint32_t state_time = 0; // Tempo para controlar o estado
    static int state = 0;          // Estado do semáforo
    static bool special_mode = false;

    if (button_pressed) {
        button_pressed = false; // Reseta o estado do botão

        // Ativa o modo especial imediatamente
        special_mode = true;
        state = 10; // Estado da sequência especial
        state_time = to_ms_since_boot(get_absolute_time()); // Resetando o tempo ao ativar o modo especial
    }

    if (special_mode) {
        switch (state) {
            case 10: // LED amarelo por 5 segundos
                gpio_put(R_PIN, 0);
                gpio_put(Y_PIN, 1);
                gpio_put(G_PIN, 0);
                gpio_put(G_PIN_PED, 0);
                
                if (to_ms_since_boot(get_absolute_time()) - state_time >= 5000) {
                    state_time = to_ms_since_boot(get_absolute_time()); // Atualiza o tempo para o próximo estado
                    state = 11;
                }
                break;

            case 11: // LED vermelho e buzzer por 15 segundos
                set_pwm_frequency(BUZ_PIN, BUZ_FREQ);
                gpio_put(R_PIN, 1);
                gpio_put(Y_PIN, 0);
                gpio_put(G_PIN, 0);
                gpio_put(G_PIN_PED, 1);
                if (to_ms_since_boot(get_absolute_time()) - state_time >= 15000) {
                    state_time = to_ms_since_boot(get_absolute_time()); // Atualiza o tempo ao sair do estado 11
                    gpio_put(G_PIN_PED, 0);
                    special_mode = false;
                    // Desativa o buzzer (PWM)
                    uint slice_num = pwm_gpio_to_slice_num(BUZ_PIN);
                    pwm_set_enabled(slice_num, false); // Desativa o slice de PWM
                    gpio_put(BUZ_PIN, 0); // Certifica que o pino está em LOW
                    state = 0; // Retorna ao funcionamento normal
                }
                break;
        }
        gpio_put(BUZ_PIN, 0);  // Desliga o buzzer
        return; // Retorna sem continuar os estados normais
    }

    // Ciclo normal do semáforo (corrigido a ordem dos estados)
    switch (state) {
        case 0:  // LED verde por 8 segundos
            gpio_put(R_PIN, 0);
            gpio_put(Y_PIN, 0);
            gpio_put(G_PIN, 1);
            if (to_ms_since_boot(get_absolute_time()) - state_time >= 8000) {
                state_time = to_ms_since_boot(get_absolute_time());
                state = 1;
            }
            break;

        case 1: // LED amarelo por 2 segundos
            gpio_put(R_PIN, 0);
            gpio_put(Y_PIN, 1);
            gpio_put(G_PIN, 0);
            if (to_ms_since_boot(get_absolute_time()) - state_time >= 2000) {
                state_time = to_ms_since_boot(get_absolute_time());
                state = 2;
            }
            break;

        case 2: // LED vermelho por 10 segundos
            gpio_put(R_PIN, 1);
            gpio_put(Y_PIN, 0);
            gpio_put(G_PIN, 0);
            if (to_ms_since_boot(get_absolute_time()) - state_time >= 10000) {
                state_time = to_ms_since_boot(get_absolute_time());
                state = 0;
            }
            break;
    }
}